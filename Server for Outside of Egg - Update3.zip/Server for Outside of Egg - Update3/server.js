// Import required packages
const express = require('express');
const path = require('path');  // Only import path once
const bodyParser = require('body-parser');
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

// Initialize the Express app
const app = express();

// Use bodyParser middleware to parse incoming JSON requests
app.use(bodyParser.json());

// Serve static files (like index.html) from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Initialize Google Generative AI
const apiKey = process.env.GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({
  model: "gemini-1.5-flash",
});

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 8192,
  responseMimeType: "text/plain",
};

// Chat route for handling requests
app.post('/chat', async (req, res) => {
  const message = req.body.message;
  try {
    const chatSession = model.startChat({
      generationConfig,
      history: [],
    });

    const result = await chatSession.sendMessage(message);
    res.json({ message: result.response.text() });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server and listen on port 3000
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
