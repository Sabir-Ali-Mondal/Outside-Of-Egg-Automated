
let lines = [];
let currentIndex = 0;
let storyGenerated = false;
let mouthOpen = false;
let speaking = false;
let speechRate = 1.0;

const chatBody = document.getElementById('chat-body');
const processBtn = document.getElementById('process-btn');
const storyInput = document.getElementById('story-input');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const playBtn = document.getElementById('play-btn');
const pauseBtn = document.getElementById('pause-btn');
const readFullBtn = document.getElementById('read-full-btn');
const stopBtn = document.getElementById('stop-btn');
const chatContainer = document.querySelector('.chat-container');
const languageSelect = document.getElementById('languageSelect');
const pasteBtn = document.getElementById('paste-btn');
const speedControl = document.getElementById('speedControl');
const speedValue = document.getElementById('speedValue');


function setup() {
    const canvas = createCanvas(200, 200);
    canvas.parent('canvas-container');
}

function draw() {
    background(240);
    drawFace();
    if (speaking) {
        mouthOpen = !mouthOpen;
    }
    frameRate(speaking ? 6 : 30);
}

function drawFace() {
    fill(255, 224, 189);
    ellipse(100, 100, 100, 100);

    fill(0);
    ellipse(80, 80, 15, 15);
    ellipse(120, 80, 15, 15);

    if (mouthOpen) {
        fill(255, 100, 100);
        arc(100, 120, 40, 20, 0, PI);
    } else {
        fill(255, 100, 100);
        arc(100, 120, 40, 10, 0, PI);
    }
}

function renderChat() {
    chatBody.innerHTML = '';
    lines.forEach((line, index) => {
        const chatMessage = document.createElement('div');
        chatMessage.className = 'chat-message';
        chatMessage.textContent = line;
        chatBody.appendChild(chatMessage);
    });
    chatContainer.style.display = 'block';
    highlightAndScroll();
}

function updateControls() {
    prevBtn.disabled = currentIndex <= 0;
    nextBtn.disabled = currentIndex >= lines.length - 1;
    pauseBtn.disabled = !speechSynthesis.speaking;
    playBtn.disabled = speechSynthesis.speaking;
}

function speakLine() {
    speaking = true;
    if (currentIndex >= lines.length) {
        speaking = false;
        updateControls();
        return;
    }
    const line = lines[currentIndex];
    const parts = line.split("...");
    const prePause = parts[0] || ""; // Text before "..."
    const postPause = parts[1] || ""; // Text after "..."

    const utterances = [];

    if (prePause) {
        const preUtterance = new SpeechSynthesisUtterance(prePause);
        preUtterance.lang = languageSelect.value;
        preUtterance.rate = speechRate;
        utterances.push(preUtterance);
    }

    // Adding a 1-second pause after the first part
    const pauseUtterance1 = new SpeechSynthesisUtterance(" ");
    pauseUtterance1.lang = languageSelect.value;
    pauseUtterance1.rate = 0.1; // Mimic pause by setting a very slow rate
    pauseUtterance1.text = " ".repeat(50); // Adjust to ensure it lasts ~1 second
    utterances.push(pauseUtterance1);

    if (postPause) {
        const postUtterance = new SpeechSynthesisUtterance(postPause);
        postUtterance.lang = languageSelect.value;
        postUtterance.rate = speechRate;
        utterances.push(postUtterance);
    }

    // Adding a 1-second pause at the end
    const pauseUtterance2 = new SpeechSynthesisUtterance(" ");
    pauseUtterance2.lang = languageSelect.value;
    pauseUtterance2.rate = 0.1; // Mimic pause by setting a very slow rate
    pauseUtterance2.text = " ".repeat(50); // Adjust to ensure it lasts ~1 second
    utterances.push(pauseUtterance2);

    // Chain utterances
    let utteranceIndex = 0;
    const speakNext = () => {
        if (utteranceIndex < utterances.length) {
            const utterance = utterances[utteranceIndex];
            utterance.onend = speakNext;
            speechSynthesis.speak(utterance);
            utteranceIndex++;
        } else {
            speaking = false;
            if (currentIndex < lines.length - 1) {
                currentIndex++;
                highlightAndScroll();
                updateControls();
                speakLine();
            } else {
                updateControls();
            }
        }
    };

    speechSynthesis.cancel();
    speakNext();
    highlightAndScroll();
}

function renderChat() {
    chatBody.innerHTML = '';
    lines.forEach((line, index) => {
        const parts = line.split("...");
        const prePause = parts[0] || ""; // Text before "..."
        const postPause = parts[1] || ""; // Text after "..."

        const chatMessage = document.createElement('div');
        chatMessage.className = 'chat-message';

        // Add styled spans for prePause and postPause
        chatMessage.innerHTML = `
    <span style="color: red;">${prePause}</span>
    <span style="color: blue;">...${postPause}</span>
`;

        chatBody.appendChild(chatMessage);
    });
    chatContainer.style.display = 'block';
    highlightAndScroll();
}

function readFullStory() {
    speaking = true;
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(lines.join('. '));
    utterance.lang = languageSelect.value;
    utterance.rate = speechRate;
    utterance.onstart = () => updateControls();
    utterance.onend = () => {
        speaking = false;
        updateControls();
    };
    utterance.onpause = () => {
        pauseBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
        pauseBtn.classList.remove('btn-warning');
        pauseBtn.classList.add('btn-success');
        updateControls();
    };
    utterance.onresume = () => {
        pauseBtn.innerHTML = '<i class="bi bi-pause-fill"></i>';
        pauseBtn.classList.remove('btn-success');
        pauseBtn.classList.add('btn-warning');
        updateControls();
    };
    speechSynthesis.speak(utterance);
    updateControls();
}

function highlightAndScroll() {
    const chatMessages = document.querySelectorAll('.chat-message');
    chatMessages.forEach((message, index) => {
        message.classList.toggle('highlight', index === currentIndex);
        message.addEventListener('click', () => {
            currentIndex = index;
            highlightAndScroll();
            if (speechSynthesis.speaking) {
                speechSynthesis.pause();
            }
            speakLine();
        });
    });
    chatMessages[currentIndex]?.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
    });
}


prevBtn.addEventListener('click', () => {
    if (currentIndex > 0) {
        currentIndex--;
        highlightAndScroll();
        speakLine();
    }
});

nextBtn.addEventListener('click', () => {
    if (currentIndex < lines.length - 1) {
        currentIndex++;
        highlightAndScroll();
        speakLine();
    }
});

playBtn.addEventListener('click', speakLine);

pauseBtn.addEventListener('click', () => {
    if (speechSynthesis.speaking) {
        speechSynthesis.pause();
        pauseBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
        pauseBtn.classList.remove('btn-warning');
        pauseBtn.classList.add('btn-success');
    } else {
        speechSynthesis.resume();
        pauseBtn.innerHTML = '<i class="bi bi-pause-fill"></i>';
        pauseBtn.classList.remove('btn-success');
        pauseBtn.classList.add('btn-warning');
    }
    speaking = !speaking;
    updateControls();
});

readFullBtn.addEventListener('click', readFullStory);

stopBtn.addEventListener('click', () => {
    speaking = false;
    speechSynthesis.cancel();
    updateControls();
});

processBtn.addEventListener('click', async () => {
    const storyText = storyInput.value;
    processBtn.disabled = true;
    try {
        await new Promise(resolve => setTimeout(resolve, 2000));

        lines = storyText.split('\n').filter(line => line.trim());
        currentIndex = 0;
        renderChat();
    } catch (error) {
        console.error("Error fetching story:", error);
        alert("Error generating story. Please try again later.");
    } finally {
        processBtn.disabled = false;
    }
});

document.getElementById('downloadStoryBtn').addEventListener('click', () => {
if (!lines || lines.length === 0) {
    alert('No story available to download.');
    return;
}

const storyContent = lines.join('\n');
const blob = new Blob([storyContent], { type: 'text/plain' });
const downloadLink = document.createElement('a');
downloadLink.href = URL.createObjectURL(blob);
downloadLink.download = 'story.txt';
downloadLink.click();
URL.revokeObjectURL(downloadLink.href);
});

document.getElementById('uploadStoryBtn').addEventListener('click', () => {
document.getElementById('uploadStoryFile').click();
});

document.getElementById('uploadStoryFile').addEventListener('change', async (event) => {
const file = event.target.files[0];

if (!file) {
    alert('No file selected.');
    return;
}

if (!file.name.endsWith('.txt')) {
    alert('Please upload a .txt file.');
    return;
}

try {
    const fileContent = await file.text();
    lines = fileContent.split('\n').filter(line => line.trim());
    currentIndex = 0;
    renderChat();
    alert('Custom story uploaded successfully!');
} catch (error) {
    console.error('Error reading file:', error);
    alert('Failed to upload story. Please try again.');
}
});
document.getElementById('generatePromptBtn').addEventListener('click', () => {
    const topic = document.getElementById('topicInput').value.trim();
    const language = document.getElementById('languageSelect').value;

    if (!topic) {
        alert('Please enter a topic.');
        return;
    }

    const prompt = `
Design an interactive learning experience for young children (ages 4-7) based on the topic: [${topic}] in ${language} Language. Provide a simple text copier option. The session should inspire curiosity, encourage imagination, and foster critical thinking about the chosen topic.

Instructions:

1. Don't use symbols in the text that are not good to listen to while text-to-speech (like . / * / #). Don't give point names and no title needed. Use simple paragraph-like text separately.

2. Introduction (1-2 sentences): Start with a fun and engaging hook to introduce the topic in a relatable and exciting way.

3. Exploration and Engagement (3 sentences): Provide a simple explanation, fun fact, or imaginative scenario about the topic to spark interest.

4. Interactive Questions (15 in total): Create open-ended questions directly related to the topic then give creative answer.It should stimulate creative or critical thinking, followed by a "..." gap only before each answer.`;

    const promptOutput = document.getElementById('promptOutput');
    promptOutput.textContent = prompt;
    storyGenerated = true;
});

document.getElementById('sendToPerplexityBtn').addEventListener('click', () => {
    const prompt = document.getElementById('promptOutput').textContent;
    navigator.clipboard.writeText(prompt).then(() => {
        const perplexityUrl = `https://www.perplexity.ai/search/new?q=${encodeURIComponent(prompt)}`;
        window.open(perplexityUrl, '_blank', 'width=800,height=600');
    });
});

document.getElementById('copyToChatGPTBtn').addEventListener('click', () => {
    const prompt = document.getElementById('promptOutput').textContent;
    navigator.clipboard.writeText(prompt).then(() => {
        const chatGPTUrl = `https://chat.openai.com/`;
        window.open(chatGPTUrl, '_blank', 'width=800,height=600');
    });
});

speedControl.addEventListener('input', () => {
    speechRate = parseFloat(speedControl.value);
    speedValue.textContent = speechRate.toFixed(1);
});

pasteBtn.addEventListener('click', async () => {
    try {
        const clipboardText = await navigator.clipboard.readText();
        storyInput.value = clipboardText;
    } catch (err) {
        alert('Failed to read from clipboard. Please allow clipboard access.');
    }
});
document.getElementById("process-btn").addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("Chatboxscroll").scrollIntoView({
        behavior: "smooth"
    });
});
updateControls();

document.getElementById('directGenerateStoryBtn').addEventListener('click', async () => {
const promptOutput = document.getElementById('promptOutput');
const prompt = promptOutput.textContent.trim();

if (!prompt) {
alert('No prompt available. Please generate a prompt first.');
return;
}

// Disable the button while processing
const generateBtn = document.getElementById('directGenerateStoryBtn');
generateBtn.disabled = true;

try {
// Send the prompt to the API
const response = await fetch('http://localhost:3000/chat', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({ message: prompt }),
});

if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
}

const data = await response.json();
const generatedStory = data.message; // Assuming the story is returned in `message`

// Populate the chatbox area with the response
lines = generatedStory.split('\n').filter(line => line.trim());
currentIndex = 0;
renderChat(); // Use the existing function to render the chat
} catch (error) {
console.error('Error generating story:', error);
alert('Failed to generate story. Please try again.');
} finally {
// Re-enable the button after processing
generateBtn.disabled = false;
}
});

// Optional: Initially disable the button if no prompt exists
window.addEventListener('DOMContentLoaded', () => {
const promptOutput = document.getElementById('promptOutput');
const generateBtn = document.getElementById('directGenerateStoryBtn');
generateBtn.disabled = !promptOutput.textContent.trim();
});

// Update the button state whenever a new prompt is generated
document.getElementById('generatePromptBtn').addEventListener('click', () => {
const promptOutput = document.getElementById('promptOutput');
const generateBtn = document.getElementById('directGenerateStoryBtn');
generateBtn.disabled = !promptOutput.textContent.trim();
});


const textToType = `A fun platform where kids strengthen their thinking and questioning abilities to become real-time thinkers.`;
const typingElement = document.getElementById("typing-text");

function autoTypeText(text) {
    let i = 0;
    const interval = setInterval(() => {
        typingElement.textContent += text.charAt(i);
        i++;
        if (i === text.length) {
            clearInterval(interval);
        }
    }, 100); // Speed of typing
}
autoTypeText(textToType);

async function fillInputWithRandomWord() {
    try {
        const response = await fetch('https://random-word-api.herokuapp.com/word?number=1');
        if (!response.ok) throw new Error("Failed to fetch the word.");
        
        const data = await response.json();
        const inputField = document.getElementById("topicInput");
        inputField.value = data[0]; // Fill the input field with the random word
    } catch (error) {
        console.error("Error fetching random word:", error);
        alert("Could not fetch a random word. Please try again.");
    }
}
